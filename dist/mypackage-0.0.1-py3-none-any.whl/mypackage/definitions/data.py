



from dataclasses import dataclass, asdict
import json

@dataclass
class BaseDC:

    def to_json(self):
        return json.dumps(asdict(self))
    
    @classmethod
    def from_json(cls, value: str):
        data = json.loads(value)
        return cls(**data)